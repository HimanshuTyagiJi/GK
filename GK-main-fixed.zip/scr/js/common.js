// Establish a global namespace to share data and functions
window.GKApp = window.GKApp || {};

// --- Single Source of Truth for Data ---
window.GKApp.searchData = [
  {
    title: "Weight & Mass Unit Conversion",
    url: "/conversion/weight-mass-unit-conversion",
    paragraph: "Convert between various units of weight and mass, such as kilograms (kg), grams (g), pounds (lb), and ounces (oz). An essential tool for science, cooking, and daily life.",
    date: "February 24, 2025",
    author: "Himanshu Tyagi",
    category: "Conversion",
    readingTime: "8 min read",
  },
  {
    title: "Volume Unit Conversion",
    url: "/conversion/volume-unit-conversion",
    paragraph: "Easily convert between volume units like liters (L), milliliters (mL), gallons, and cubic meters. Essential for chemistry, cooking, and engineering.",
    date: "February 23, 2025",
    author: "Owner",
    category: "Conversion",
    readingTime: "8 min read",
  },
  {
    title: "Time Unit Conversion",
    url: "/conversion/time-unit-conversion",
    paragraph: "Convert time between seconds, minutes, hours, days, and more. A fundamental skill for scheduling, physics calculations, and everyday planning.",
    date: "February 22, 2025",
    author: "Golu Tyagi",
    category: "Conversion",
    readingTime: "7 min read",
  },
  {
    title: "Temperature Unit Conversion - defination,use",
    url: "/conversion/temperature-unit-conversion",
    paragraph: "Switch between temperature scales including Celsius, Fahrenheit, and Kelvin. Crucial for weather forecasting, scientific experiments, and cooking.",
    date: "February 21, 2025",
    author: "Himanshu Tyagi",
    category: "Conversion",
    readingTime: "7 min read",
  },
  {
    title: "Speed Unit Conversion",
    url: "/conversion/speed-unit-conversion",
    paragraph: "Convert speed units such as meters per second (m/s), kilometers per hour (km/h), and miles per hour (mph). Useful in physics, travel, and sports.",
    date: "February 20, 2025",
    author: "Owner",
    category: "Conversion",
    readingTime: "8 min read",
  },
  {
    title: "Pressure Unit Conversion",
    url: "/conversion/pressure-unit-conversion",
    paragraph: "Convert between pressure units like Pascal (Pa), atmospheres (atm), and pounds per square inch (psi). Important for engineering, meteorology, and physics.",
    date: "February 19, 2025",
    author: "Golu Tyagi",
    category: "Conversion",
    readingTime: "7 min read",
  },
  {
    title: "Power Unit Conversion",
    url: "/conversion/power-unit-conversion",
    paragraph: "Convert units of power like watts (W), horsepower (hp), and kilowatts (kW). Essential for physics, engineering, and understanding energy consumption.",
    date: "February 18, 2025",
    author: "Himanshu Tyagi",
    category: "Conversion",
    readingTime: "7 min read",
  },
  {
    title: "Length Unit Conversion",
    url: "/conversion/length-unit-conversion",
    paragraph: "Convert between units of length, including meters (m), kilometers (km), miles, and inches. A basic necessity for measurement and construction.",
    date: "February 17, 2025",
    author: "Owner",
    category: "Conversion",
    readingTime: "8 min read",
  },
  {
    title: "Area Unit Conversion",
    url: "/conversion/area-unit-conversion",
    paragraph: "Convert area units such as square meters, square feet, acres, and hectares. Vital for real estate, agriculture, and construction planning.",
    date: "February 16, 2025",
    author: "Golu Tyagi",
    category: "Conversion",
    readingTime: "7 min read",
  },
  {
    title: "Angle Unit Conversion",
    url: "/conversion/angle-unit-conversion",
    paragraph: "Convert between degrees, radians, and other angular units. A core concept in mathematics, physics, and engineering for measuring rotation.",
    date: "February 15, 2025",
    author: "Himanshu Tyagi",
    category: "Conversion",
    readingTime: "8 min read",
  },
 {
  title: "Unit Conversion",
  url: "/conversion",
  paragraph: "A comprehensive tool for converting various types of measurement units, including length, mass, volume, and more, for academic and practical applications.",
  date: "February 14, 2025",
  author: "Owner",
  category: "Conversion",
  readingTime: "15 min read",
}
,
  {
    title: "निबंध: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/essay-in-hindi.html",
    paragraph: "निबंध लेखन विचारों को व्यवस्थित रूप से प्रस्तुत करने की एक कला है। इस खंड में निबंध के प्रकार, संरचना और प्रभावी लेखन की तकनीकों को जानें।",
    date: "February 13, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "10 min read",
  },
  {
    title: "पत्र-लेखन: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/letter-writing-in-hindi.html",
    paragraph: "पत्र-लेखन संचार का एक महत्वपूर्ण माध्यम है। यहाँ औपचारिक और अनौपचारिक पत्रों के प्रारूप, भाषा-शैली और उदाहरणों का विस्तृत वर्णन है।",
    date: "February 12, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "अपठित-गद्यांश: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/unseen-passage-in-hindi.html",
    paragraph: "अपठित गद्यांश का उद्देश्य छात्रों की समझ और विश्लेषण क्षमता का मूल्यांकन करना है। यहाँ गद्यांश को हल करने की सही विधि और रणनीतियाँ बताई गई हैं।",
    date: "February 11, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "अनुच्छेद-लेखन: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/paragraph-writing-in-hindi.html",
    paragraph: "अनुच्छेद-लेखन किसी एक विषय पर संक्षिप्त और सारगर्भित जानकारी प्रस्तुत करने की कला है। यहाँ प्रभावी अनुच्छेद लिखने के नियम और उदाहरण दिए गए हैं।",
    date: "February 10, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "अलंकार: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/alankar-in-hindi.html",
    paragraph: "अलंकार काव्य की शोभा बढ़ाने वाले तत्व हैं। इस खंड में शब्दालंकार और अर्थालंकार के प्रमुख भेदों को उदाहरण सहित समझाया गया है।",
    date: "February 9, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "10 min read",
  },
  {
    title: "छन्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/chhand-in-hindi.html",
    paragraph: "छन्द काव्य में वर्णों या मात्राओं की नियमित संख्या के विन्यास को कहते हैं। यहाँ मात्रिक और वर्णिक छंदों के लक्षण और उदाहरण दिए गए हैं।",
    date: "February 8, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "रस: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/ras-in-hindi.html",
    paragraph: "रस का शाब्दिक अर्थ है 'आनंद'। काव्य को पढ़ने या सुनने से जिस आनंद की अनुभूति होती है, उसे रस कहते हैं। यहाँ सभी रसों का वर्णन है।",
    date: "February 7, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "युग्म शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/yugm-shabd.html",
    paragraph: "युग्म-शब्द वे शब्द होते हैं जो उच्चारण में समान लगते हैं, परन्तु उनके अर्थ भिन्न होते हैं। यहाँ ऐसे शब्दों के उदाहरण दिए गए हैं।",
    date: "February 6, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "6 min read",
  },
  {
    title: "त्रुटिसम भिन्नार्थक शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/pairs-of-similar-words.html",
    paragraph: "ये वे शब्द हैं जो सुनने में लगभग समान लगते हैं, पर उनकी वर्तनी और अर्थ में सूक्ष्म अंतर होता है। यह भाषा को समृद्ध बनाता है।",
    date: "February 5, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "7 min read",
  },
  {
    title: "एकार्थक प्रतीत होने वाले शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/words-apparently-similar-in-meanings-in-hindi.html",
    paragraph: "कुछ शब्द देखने में समान अर्थ वाले लगते हैं, लेकिन उनके प्रयोग और अर्थ में सूक्ष्म भिन्नता होती है। यहाँ ऐसे ही शब्दों का संकलन है।",
    date: "February 4, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "6 min read",
  },
  {
    title: "अनेकार्थी-शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/words-of-many-meanings-in-hindi.html",
    paragraph: "अनेकार्थी शब्द वे होते हैं जिनके एक से अधिक अर्थ निकलते हैं। प्रसंग के अनुसार उनका सही अर्थ समझा जाता है।",
    date: "February 3, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "7 min read",
  },
  {
    title: "अनेक शब्दों के लिए एक शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/one-word-substitution-in-hindi.html",
    paragraph: "भाषा को संक्षिप्त और प्रभावशाली बनाने के लिए वाक्यांश या अनेक शब्दों के स्थान पर एक शब्द का प्रयोग किया जाता है।",
    date: "February 2, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "लोकोक्तियाँ: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/proverbs-in-hindi.html",
    paragraph: "लोकोक्तियाँ या कहावतें ऐसे वाक्यांश हैं जो अपने अनुभव और परंपरा के आधार पर बने हैं और किसी सत्य को प्रकट करते हैं।",
    date: "February 1, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "मुहावरे: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/idioms-in-hindi.html",
    paragraph: "मुहावरे ऐसे वाक्यांश होते हैं जो अपने सामान्य अर्थ को छोड़कर किसी विशेष अर्थ को व्यक्त करते हैं, जिससे भाषा रोचक बनती है।",
    date: "January 31, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "पर्यायवाची-शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/synonyms-in-hindi.html",
    paragraph: "पर्यायवाची शब्द (समानार्थक शब्द) उन शब्दों को कहते हैं जिनके अर्थ समान होते हैं। यह शब्द-भंडार को समृद्ध करते हैं।",
    date: "January 30, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "विलोम-शब्द: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/antonyms-in-hindi.html",
    paragraph: "विलोम शब्द (विपरीतार्थक शब्द) वे शब्द होते हैं जो किसी दूसरे शब्द का उल्टा अर्थ बताते हैं। यह भाषा में संतुलन लाते हैं।",
    date: "January 29, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "देशज-विदेशज: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/deshaj-videshaj-in-hindi.html",
    paragraph: "देशज शब्द स्थानीय बोलियों से आते हैं, जबकि विदेशज शब्द अन्य भाषाओं से लिए गए हैं। यह हिंदी भाषा की विविधता को दर्शाता है।",
    date: "January 28, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "तत्सम-तद्भव: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/tatsam-tadbhav-in-hindi.html",
    paragraph: "तत्सम शब्द संस्कृत से ज्यों के त्यों लिए गए हैं, जबकि तद्भव शब्द संस्कृत से परिवर्तित होकर बने हैं।",
    date: "January 27, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "समास: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/compound-in-hindi.html",
    paragraph: "समास दो या दो से अधिक शब्दों को मिलाकर एक नया और संक्षिप्त शब्द बनाने की प्रक्रिया है। इसके प्रमुख भेदों का वर्णन यहाँ है।",
    date: "January 26, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "10 min read",
  },
  {
    title: "संधि: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/joining.html",
    paragraph: "संधि का अर्थ है 'मेल'। दो निकटवर्ती वर्णों के मेल से जो विकार (परिवर्तन) होता है, उसे संधि कहते हैं।",
    date: "January 25, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "10 min read",
  },
  {
    title: "प्रत्यय: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/suffix-in-hindi.html",
    paragraph: "प्रत्यय वे शब्दांश हैं जो किसी शब्द के अंत में जुड़कर उसके अर्थ में विशेषता या परिवर्तन लाते हैं।",
    date: "January 24, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "उपसर्ग: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/prefix-in-hindi.html",
    paragraph: "उपसर्ग वे शब्दांश हैं जो किसी शब्द के आरंभ में जुड़कर उसके अर्थ को बदल देते हैं या नया अर्थ देते हैं।",
    date: "January 23, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "विराम-चिन्ह: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/punctuation-in-hindi.html",
    paragraph: "विराम-चिन्हों का प्रयोग भाषा में स्पष्टता और भावों की सही अभिव्यक्ति के लिए किया जाता है। यहाँ सभी चिन्हों का वर्णन है।",
    date: "January 22, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "पुरुष: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/person-in-hindi.html",
    paragraph: "व्याकरण में पुरुष से तात्पर्य वक्ता, श्रोता और अन्य व्यक्ति से है। इसके तीन भेद हैं - उत्तम, मध्यम और अन्य पुरुष।",
    date: "January 21, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "6 min read",
  },
  {
    title: "वाच्य: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/voice-in-hindi.html",
    paragraph: "वाच्य क्रिया का वह रूप है जिससे यह पता चलता है कि वाक्य में कर्ता, कर्म या भाव में से किसकी प्रधानता है।",
    date: "January 20, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "7 min read",
  },
  {
    title: "निपात: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/particle-in-hindi.html",
    paragraph: "निपात वे अव्यय शब्द हैं जो किसी शब्द या पद के बाद लगकर उसके अर्थ में विशेष प्रकार का बल या भाव उत्पन्न करते हैं।",
    date: "January 19, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "6 min read",
  },
  {
    title: "अव्यय: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/indeclinable-words-in-hindi.html",
    paragraph: "अव्यय या अविकारी शब्द वे होते हैं जिनमें लिंग, वचन, पुरुष, कारक आदि के कारण कोई विकार या परिवर्तन नहीं होता।",
    date: "January 18, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "7 min read",
  },
  {
    title: "काल: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/tense-in-hindi.html",
    paragraph: "काल क्रिया के उस रूप को कहते हैं जिससे उसके करने या होने के समय का बोध होता है। इसके तीन मुख्य भेद हैं - भूत, वर्तमान, भविष्य।",
    date: "January 17, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "क्रिया: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/verb-in-hindi.html",
    paragraph: "जिस शब्द से किसी कार्य के करने या होने का बोध हो, उसे क्रिया कहते हैं। यह सकर्मक और अकर्मक दो प्रकार की होती है।",
    date: "January 16, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "विशेषण: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/adjective-in-hindi.html",
    paragraph: "जो शब्द संज्ञा या सर्वनाम की विशेषता बताते हैं, उन्हें विशेषण कहते हैं। यह गुण, संख्या, परिमाण आदि से संबंधित हो सकते हैं।",
    date: "January 15, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "सर्वनाम: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/pronoun-in-hindi.html",
    paragraph: "संज्ञा के स्थान पर प्रयोग होने वाले शब्दों को सर्वनाम कहते हैं। जैसे - मैं, तुम, वह, यह आदि।",
    date: "January 14, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "कारक: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/case-in-hindi.html",
    paragraph: "कारक संज्ञा या सर्वनाम का क्रिया के साथ संबंध बताते हैं। हिंदी में आठ कारक होते हैं, जिनके अपने विभक्ति चिन्ह होते हैं।",
    date: "January 13, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "लिंग: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/gender-in-hindi.html",
    paragraph: "जिस चिह्न से यह पता चले कि कोई संज्ञा पुरुष जाति की है या स्त्री जाति की, उसे लिंग कहते हैं। इसके दो भेद हैं - पुल्लिंग और स्त्रीलिंग।",
    date: "January 12, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "8 min read",
  },
  {
    title: "वचन: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/number-in-hindi.html",
    paragraph: "शब्द के जिस रूप से उसके एक या अनेक होने का बोध हो, उसे वचन कहते हैं। हिंदी में दो वचन हैं - एकवचन और बहुवचन।",
    date: "January 11, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "7 min read",
  },
  {
    title: "संज्ञा: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/noun-in-hindi.html",
    paragraph: "किसी व्यक्ति, वस्तु, स्थान, या भाव के नाम को संज्ञा कहते हैं। इसके मुख्य भेद व्यक्तिवाचक, जातिवाचक, और भाववाचक हैं।",
    date: "January 10, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "वाक्य-विचार: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/syntax-in-hindi.html",
    paragraph: "शब्दों का व्यवस्थित समूह जिससे कोई अर्थ प्रकट हो, वाक्य कहलाता है। यहाँ रचना और अर्थ के आधार पर वाक्य के भेद बताए गए हैं।",
    date: "January 9, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "शब्द-विचार: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/morphology-in-hindi.html",
    paragraph: "वर्णों के सार्थक समूह को शब्द कहते हैं। यहाँ उत्पत्ति, रचना, प्रयोग और अर्थ के आधार पर शब्दों के वर्गीकरण का वर्णन है।",
    date: "January 8, 2025",
    author: "Golu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "वर्ण-विचार: परिभाषा, भेद, उदाहरण",
    url: "vyakaran/phonology-in-hindi.html",
    paragraph: "भाषा की सबसे छोटी इकाई वर्ण कहलाती है। इस खंड में स्वर और व्यंजन वर्णों के भेद, उच्चारण स्थान और वर्गीकरण की जानकारी है।",
    date: "January 7, 2025",
    author: "Himanshu Tyagi",
    category: "Vyakaran",
    readingTime: "9 min read",
  },
  {
    title: "भाषा और व्याकरण: परिभाषा, भेद, उदाहरण",
    url: "vyakaran-language.html",
    paragraph: "भाषा विचारों के आदान-प्रदान का माध्यम है, और व्याकरण भाषा को शुद्ध रूप से लिखने और बोलने के नियम सिखाता है।",
    date: "January 6, 2025",
    author: "Owner",
    category: "Vyakaran",
    readingTime: "11 min read",
  },
];

// --- HINGLISH TO HINDI TRANSLITERATION ---
window.GKApp.transliterateRomanToHindi = (input) => {
    const map = {
        consonants: {
            // Complex consonants
            'ksh': 'क्ष', 'gy': 'ज्ञ', 'dny': 'ज्ञ', 'jn': 'ज्ञ', 'shr': 'श्र',
            // 2-letter consonants
            'kh': 'ख', 'gh': 'घ', 'chh': 'छ', 'jh': 'झ',
            'th': 'थ', 'dh': 'ध', 'ph': 'फ', 'bh': 'भ',
            'shh': 'ष', 'sh': 'श', 'tr': 'त्र',
            'gn': 'ङ', 'ny': 'ञ',
            // Single consonants
            'k': 'क', 'g': 'ग', 'c': 'क', 'j': 'ज',
            't': 'त', 'd': 'द', 'n': 'न',
            'p': 'प', 'b': 'ब', 'm': 'म',
            'y': 'य', 'r': 'र', 'l': 'ल',
            'v': 'व', 'w': 'व', 's': 'स', 'h': 'ह',
            'z': 'ज़', 'f': 'फ़', 'q': 'क़', 'x': 'क्ष'
        },
        vowels: {
            'aa': 'आ', 'ee': 'ई', 'ii': 'ई', 'oo': 'ऊ', 'uu': 'ऊ',
            'ai': 'ऐ', 'au': 'औ', 'ri': 'ऋ',
            'a': 'अ', 'i': 'इ', 'e': 'ए',
            'o': 'ओ', 'u': 'उ'
        },
        matras: {
            'aa': 'ा', 'ee': 'ी', 'ii': 'ी', 'oo': 'ू', 'uu': 'ू',
            'ai': 'ै', 'au': 'ौ', 'ri': 'ृ',
            'a': '', 'i': 'ि', 'e': 'े',
            'o': 'ो', 'u': 'ु'
        },
        symbols: {
            'an': 'ं', 'am': 'ं', 'ah': 'ः',
            'om': 'ॐ', 'shree': 'श्री'
        }
    };

    let output = '';
    let i = 0;

    while (i < input.length) {
        let matched = false;

        // --- Try 4-char (e.g., shree, dnya)
        if (i + 3 < input.length) {
            const fourChar = input.substring(i, i + 4).toLowerCase();
            if (map.consonants[fourChar] || map.vowels[fourChar] || map.symbols[fourChar]) {
                output += map.consonants[fourChar] || map.vowels[fourChar] || map.symbols[fourChar];
                i += 4;
                matched = true;
            }
        }

        // --- Try 3-char combos
        if (!matched && i + 2 < input.length) {
            const threeChar = input.substring(i, i + 3).toLowerCase();
            if (map.consonants[threeChar] || map.vowels[threeChar] || map.symbols[threeChar]) {
                output += map.consonants[threeChar] || map.vowels[threeChar] || map.symbols[threeChar];
                i += 3;
                matched = true;
            }
        }

        // --- Try 2-char combos
        if (!matched && i + 1 < input.length) {
            const twoChar = input.substring(i, i + 2).toLowerCase();
            if (map.consonants[twoChar] || map.vowels[twoChar] || map.matras[twoChar] || map.symbols[twoChar]) {
                const lastChar = output.slice(-1);
                const lastIsConsonant = Object.values(map.consonants).includes(lastChar);

                if (lastIsConsonant && map.matras[twoChar] !== undefined) {
                    if (output.endsWith('्')) output = output.slice(0, -1);
                    output += map.matras[twoChar];
                } else {
                    output += map.consonants[twoChar] || map.vowels[twoChar] || map.symbols[twoChar];
                }
                i += 2;
                matched = true;
            }
        }

        // --- Single char fallback
        if (!matched) {
            const oneChar = input.charAt(i).toLowerCase();
            const lastChar = output.slice(-1);
            const lastIsConsonant = Object.values(map.consonants).includes(lastChar);

            if (lastIsConsonant && map.matras[oneChar] !== undefined) {
                if (output.endsWith('्')) output = output.slice(0, -1);
                output += map.matras[oneChar];
            } else if (map.vowels[oneChar]) {
                output += map.vowels[oneChar];
            } else if (map.consonants[oneChar]) {
                output += map.consonants[oneChar];
                // Add halant for consonant clusters
                if (i + 1 < input.length && map.consonants[input.charAt(i + 1)]) {
                    output += '्';
                }
            } else {
                output += oneChar;
            }
            i++;
        }
    }

    return output;
};


// --- LEVENSHTEIN DISTANCE ALGORITHM for Typo Tolerance ---
window.GKApp.levenshtein = (s1, s2) => {
    if (s1.length > s2.length) { [s1, s2] = [s2, s1]; }
    const distances = Array(s1.length + 1).fill(0).map((_, i) => i);
    for (let i = 0; i < s2.length; i++) {
        let prev = i + 1;
        for (let j = 0; j < s1.length; j++) {
            const current = distances[j];
            distances[j] = prev;
            prev = s1[j] === s2[i] ? current : 1 + Math.min(current, prev, distances[j+1]);
        }
        distances[s1.length] = prev;
    }
    return distances[s1.length];
};

// --- ADVANCED FUZZY SEARCH with TYPO TOLERANCE ---
window.GKApp.fuzzySearch = function (query, items) {
    const lowerCaseQuery = query.toLowerCase().trim();
    if (!lowerCaseQuery) return [];

    const hindiQuery = window.GKApp.transliterateRomanToHindi(lowerCaseQuery);
    
    // Split query by space or common punctuation
    const queryWords = lowerCaseQuery.split(/[\s,،।.]+/).filter(w => w);
    const hindiQueryWords = hindiQuery.split(/[\s,،।.]+/).filter(w => w);
    const allQueryWords = [...new Set([...queryWords, ...hindiQueryWords])];

    const results = items.map(item => {
        let score = 0;
        const matchedWords = new Set();
        
        // Combine title and paragraph for a full search field
        const content = `${item.title} ${item.paragraph}`;
        const contentWords = content.split(/[\s,،।.]+/);

        allQueryWords.forEach(qWord => {
            let bestMatchScore = 0;
            
            contentWords.forEach(cWord => {
                const distance = window.GKApp.levenshtein(qWord.toLowerCase(), cWord.toLowerCase());
                // Allow more typos for longer words
                const threshold = qWord.length > 4 ? 2 : 1;

                if (distance <= threshold) {
                    let currentScore = 0;
                    // Higher score for title match
                    if (item.title.toLowerCase().includes(cWord.toLowerCase())) {
                       currentScore = 15;
                    } else {
                       currentScore = 5;
                    }
                    // Bonus for being a better match (less distance)
                    currentScore -= distance * 2;
                    
                    if(currentScore > bestMatchScore) {
                        bestMatchScore = currentScore;
                    }
                }
            });
            
            if (bestMatchScore > 0) {
                score += bestMatchScore;
                matchedWords.add(qWord);
            }
        });
        
        // Bonus score if all query words are matched
        if (matchedWords.size === allQueryWords.length) {
            score *= 1.5;
        }

        return { item, score };
    })
    .filter(result => result.score > 2) // Set a minimum threshold to avoid irrelevant results
    .sort((a, b) => b.score - a.score)
    .map(result => result.item);
    
  return [...new Map(results.map((item) => [item.url, item])).values()];
};


// --- SVG Placeholder for Search Results ---
window.GKApp.generatePlaceholderSVG = (title = 'G') => {
    const text = title.charAt(0).toUpperCase();
    let hash = 0;
    for (let i = 0; i < title.length; i++) {
        hash = title.charCodeAt(i) + ((hash << 5) - hash);
    }
    const h = Math.abs(hash % 360);
    const color = `hsl(${h}, 65%, 55%)`;
    const svg = `<svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
        <rect width="40" height="40" rx="8" fill="${color}" />
        <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#fff" text-anchor="middle" dy=".3em">${text}</text>
    </svg>`;
    return svg;
};


// --- ADVANCED CONCEPTUAL IMAGE GENERATOR ---
window.GKApp.generateConceptImage = (() => {
    const W = 640, H = 360;
    const BASE_W = 1280, BASE_H = 720;
    const S = W / BASE_W;

    const palettes = [
        { bg1: '#6a11cb', bg2: '#2575fc', primary: '#ffffff', accent: '#f5d142' }, { bg1: '#00c6ff', bg2: '#0072ff', primary: '#ffffff', accent: '#fefefe' },
        { bg1: '#f7971e', bg2: '#ffd200', primary: '#434343', accent: '#ffffff' }, { bg1: '#34e89e', bg2: '#08aeea', primary: '#ffffff', accent: '#f6f0ea' },
        { bg1: '#ff4b1f', bg2: '#ff9068', primary: '#ffffff', accent: '#f7f2b2' }, { bg1: '#1a2a6c', bg2: '#b21f1f', bg3: '#fdbb2d', primary: '#ffffff', accent: '#eeeeee' },
        { bg1: '#8e2de2', bg2: '#4a00e0', primary: '#ffffff', accent: '#d4d4d4' }, { bg1: '#1d2b64', bg2: '#f8cdda', primary: '#ffffff', accent: '#f0f0f0' },
        { bg1: '#2193b0', bg2: '#6dd5ed', primary: '#ffffff', accent: '#f5f5f5' }, { bg1: '#ff512f', bg2: '#dd2476', primary: '#ffffff', accent: '#fdd835' },
        { bg1: '#43cea2', bg2: '#185a9d', primary: '#ffffff', accent: '#e0f2f1' }, { bg1: '#c33764', bg2: '#1d2671', primary: '#ffffff', accent: '#fce4ec' },
        { bg1: '#5614B0', bg2: '#dbd65c', primary: '#ffffff', accent: '#f3e5f5' }, { bg1: '#0f2027', bg2: '#203a43', bg3: '#2c5364', primary: '#ffffff', accent: '#cfd8dc' },
        { bg1: '#141E30', bg2: '#243B55', primary: '#ffffff', accent: '#90a4ae' }, { bg1: '#2b5876', bg2: '#4e4376', primary: '#ffffff', accent: '#e8eaf6' },
        { bg1: '#e52d27', bg2: '#b31217', primary: '#ffffff', accent: '#ffebee' }, { bg1: '#00416A', bg2: '#799F0C', bg3: '#FFE000', primary: '#ffffff', accent: '#f1f8e9' },
        { bg1: '#373B44', bg2: '#4286f4', primary: '#ffffff', accent: '#e3f2fd' }, { bg1: '#1e3c72', bg2: '#2a5298', primary: '#ffffff', accent: '#d1d9ff' },
        { bg1: '#3a6186', bg2: '#89253e', primary: '#ffffff', accent: '#fbe9e7' }, { bg1: '#16222A', bg2: '#3A6073', primary: '#ffffff', accent: '#eceff1' },
        { bg1: '#4b6cb7', bg2: '#182848', primary: '#ffffff', accent: '#e7e9f8' }, { bg1: '#7b4397', bg2: '#dc2430', primary: '#ffffff', accent: '#fae8ff' },
        { bg1: '#360033', bg2: '#0b8793', primary: '#ffffff', accent: '#e0f7fa' }
    ];

    function getPalette(title) {
        let hash = 0;
        for (let i = 0; i < title.length; i++) hash = title.charCodeAt(i) + ((hash << 5) - hash);
        return palettes[Math.abs(hash % palettes.length)];
    }

    function drawBackground(ctx, palette, w, h) {
        const gradient = ctx.createLinearGradient(0, 0, w, h);
        gradient.addColorStop(0, palette.bg1);
        gradient.addColorStop(1, palette.bg2);
        if (palette.bg3) gradient.addColorStop(0.5, palette.bg3);
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, w, h);
    }

    function drawGeometricPattern(ctx, w, h) {
        ctx.save();
        ctx.globalAlpha = 0.04;
        for (let i = 0; i < 60; i++) {
            const x = Math.random() * w, y = Math.random() * h, size = Math.random() * 80 + 20;
            ctx.fillStyle = 'white';
            ctx.beginPath();
            const type = Math.random();
            if (type < 0.3) ctx.arc(x, y, size / 2, 0, 2 * Math.PI);
            else if (type < 0.6) ctx.rect(x - size / 2, y - size / 2, size, size);
            else { ctx.moveTo(x, y - size / 2); ctx.lineTo(x + size / 2, y + size / 2); ctx.lineTo(x - size / 2, y + size / 2); ctx.closePath(); }
            ctx.fill();
        }
        ctx.restore();
    }

    function wrapText(ctx, text, x, y, maxWidth, lineHeight, palette) {
        const fontSize = text.length > 30 ? 75 : 90;
        ctx.font = `bold ${fontSize}px 'Arial', sans-serif`;
        ctx.fillStyle = palette.primary;
        ctx.strokeStyle = 'rgba(0,0,0,0.2)';
        ctx.lineWidth = 8;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,0.35)';
        ctx.shadowBlur = 12;
        ctx.shadowOffsetX = 6;
        ctx.shadowOffsetY = 6;

        const words = text.split(' ');
        let line = '', lines = [];
        for (let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            if (ctx.measureText(testLine).width > maxWidth && n > 0) {
                lines.push(line);
                line = words[n] + ' ';
            } else line = testLine;
        }
        lines.push(line);

        const startY = y - (lineHeight * (lines.length - 1)) / 2;
        lines.forEach((currentLine, i) => {
            currentLine = currentLine.trim();
            ctx.strokeText(currentLine, x, startY + i * lineHeight);
            ctx.fillText(currentLine, x, startY + i * lineHeight);
        });
        ctx.shadowColor = 'transparent';
    }

    function drawBookAndPencil(ctx, palette, w, h) {
        ctx.save();
        ctx.globalAlpha = 0.3;
        ctx.strokeStyle = palette.primary;
        ctx.fillStyle = palette.accent;
        ctx.lineWidth = 10;
        // Book
        ctx.beginPath();
        ctx.moveTo(w * 0.1, h * 0.8);
        ctx.quadraticCurveTo(w * 0.25, h * 0.6, w * 0.4, h * 0.85);
        ctx.quadraticCurveTo(w * 0.25, h * 0.9, w * 0.1, h * 0.8);
        ctx.fill();
        ctx.stroke();
        // Pencil
        ctx.translate(w * 0.8, h * 0.2);
        ctx.rotate(0.5);
        ctx.fillRect(-120, -15, 240, 30);
        ctx.strokeRect(-120, -15, 240, 30);
        ctx.beginPath();
        ctx.moveTo(120, -15);
        ctx.lineTo(150, 0);
        ctx.lineTo(120, 15);
        ctx.closePath();
        ctx.fillStyle = '#333';
        ctx.fill();
        ctx.restore();
    }
    
    function drawDevanagari(ctx, palette, w, h) {
        ctx.save();
        ctx.globalAlpha = 0.2;
        ctx.fillStyle = palette.accent;
        ctx.font = "250px 'Arial', sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("अ", w * 0.2, h * 0.3);
        ctx.fillText("क", w * 0.8, h * 0.7);
        ctx.restore();
    }

    function drawMathSymbols(ctx, palette, w, h) {
        ctx.save();
        ctx.globalAlpha = 0.4;
        ctx.strokeStyle = palette.primary;
        ctx.fillStyle = palette.accent;
        ctx.lineWidth = 8;
        // Protractor
        ctx.beginPath();
        ctx.arc(w * 0.2, h * 0.8, 150, Math.PI, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // Ruler/Triangle
        ctx.translate(w * 0.8, h * 0.25);
        ctx.rotate(0.4);
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.lineTo(250, 50);
        ctx.lineTo(50, 250);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    }

    function drawCodeAndScreen(ctx, palette, w, h) {
        ctx.save();
        ctx.globalAlpha = 0.3;
        ctx.strokeStyle = palette.primary;
        ctx.fillStyle = palette.accent;
        ctx.lineWidth = 12;
        // Screen
        ctx.beginPath();
        ctx.roundRect(w * 0.15, h * 0.2, w * 0.7, h * 0.6, 30);
        ctx.fill();
        ctx.stroke();
        // Code symbols
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = palette.primary;
        ctx.font = "bold 100px 'Courier New', monospace";
        ctx.fillText("</>", w * 0.5, h * 0.5);
        ctx.restore();
    }

    function createImageFor(title) {
        const canvas = document.createElement('canvas');
        canvas.width = W; canvas.height = H;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, W, H);
        ctx.scale(S, S);

        const palette = getPalette(title);
        const name = title.toLowerCase();

        drawBackground(ctx, palette, BASE_W, BASE_H);
        drawGeometricPattern(ctx, BASE_W, BASE_H);

        if (name.includes("vyakaran") || name.includes("hindi") || name.includes("विशेषण") || name.includes("सर्वनाम") || name.includes("संज्ञा")) {
            drawDevanagari(ctx, palette, BASE_W, BASE_H);
            drawBookAndPencil(ctx, palette, BASE_W, BASE_H);
        } else if (name.includes("conversion") || name.includes("unit") || name.includes("mass") || name.includes("weight")) {
            drawMathSymbols(ctx, palette, BASE_W, BASE_H);
        } else if (name.includes("computer")) {
            drawCodeAndScreen(ctx, palette, BASE_W, BASE_H);
        }

        wrapText(ctx, title, BASE_W / 2, BASE_H / 2, BASE_W * 0.8, 100, palette);

        ctx.font = "600 28px 'Arial', sans-serif";
        ctx.fillStyle = palette.primary;
        ctx.textAlign = "right";
        ctx.textBaseline = "bottom";
        ctx.globalAlpha = 0.7;
        ctx.fillText("gklearnstudy.in", BASE_W - 30, BASE_H - 25);
        ctx.globalAlpha = 1;

        return canvas.toDataURL('image/png');
    }

    return createImageFor;
})();


document.addEventListener("DOMContentLoaded", () => {
    const POSTS_INITIAL_LOAD = 40;
    const POSTS_PER_PAGE = 20;
    const postsContainer = document.getElementById("post-grid");
    const postFilterInput = document.getElementById("post-filter-input");
    const categoryListContainer = document.querySelector(".category-list");
    const loadMoreBtn = document.getElementById("load-more-btn");
    
    if (!postsContainer || !loadMoreBtn) {
      console.error("Required elements for post grid not found.");
      return;
    }

    const allPosts = window.GKApp.searchData;
    let currentFilteredPosts = [...allPosts];
    let visiblePostCount = POSTS_INITIAL_LOAD;

    const renderPosts = (posts) => {
        postsContainer.innerHTML = "";
        if (posts.length === 0) {
            postsContainer.innerHTML = '<p class="no-posts-found">No articles match your filter.</p>';
            return;
        }

        const fragment = document.createDocumentFragment();
        posts.forEach((post, index) => {
            const card = document.createElement('article');
            card.className = 'card';
            card.setAttribute('aria-label', post.title);
            card.dataset.index = index; 

            const imageHtml = post.svg || `<img src="${window.GKApp.generateConceptImage(post.title)}" alt="${post.title}" loading="lazy" width="320" height="180">`;

            const clipPathId = `circle-clip-avatar-gt-${index}`;

            const metaBlock = `
                <div class="post-meta-container">
                    <div class="byline">
                        <a href="profile.html" aria-label="Author Profile">
                            <div class="author-avatar">
                                <svg width="40" height="40" viewBox="0 0 300 300">
                                    <circle cx="150" cy="150" r="150" fill="white"></circle>
                                    <text x="50%" y="35%" font-size="90" font-weight="bold" fill="red" text-anchor="middle">GK</text>
                                    <text x="50%" y="65%" font-size="38" fill="purple" text-anchor="middle">Learn Study</text>
                                    <clipPath id="${clipPathId}"><circle cx="150" cy="150" r="150"></circle></clipPath>
                                    <g clip-path="url(#${clipPathId})">
                                        <path fill="#c0a4fb" fill-opacity="1"><animate attributeName="d" dur="8s" repeatCount="indefinite" values="M0 230 Q 75 210, 150 230 T 300 210 L 300 300 L 0 300 Z; M0 240 Q 75 260, 150 240 T 300 250 L 300 300 L 0 300 Z; M0 230 Q 75 210, 150 230 T 300 210 L 300 300 L 0 300 Z"></animate></path>
                                        <path fill="#641ef9" fill-opacity="0.7"><animate attributeName="d" dur="7s" repeatCount="indefinite" values="M0 220 Q 75 245, 150 220 T 300 235 L 300 300 L 0 300 Z; M0 250 Q 75 220, 150 250 T 300 220 L 300 300 L 0 300 Z; M0 220 Q 75 245, 150 220 T 300 235 L 300 300 L 0 300 Z"></animate></path>
                                    </g>
                                </svg>
                            </div>
                        </a>
                        <div class="author-details">
                            <span class="author vcard">by <span class="name"><a class="url fn n" href="profile.html" rel="author">${post.author}</a></span></span>
                            <span class="entry-modified-date">Updated on <time class="entry-date updated">${post.date}</time>${post.readingTime ? ` &bull; ${post.readingTime}` : ''}</span>
                        </div>
                    </div>
                    <div class="share-button-wrapper">
                        <button class="share-button" title="Share this page">
                            <svg class="share-icon" viewBox="0 0 24 24" width="20" height="20" role="img" aria-hidden="true"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"></path></svg>
                            <span>Share</span>
                        </button>
                    </div>
                </div>`;

            card.innerHTML = `
                <div class="card-thumbnail" aria-hidden="true">
                    <a href="categories.html" class="category-badge">${post.category}</a>
                    <a href="${post.url}" class="card-image-link" tabindex="-1">${imageHtml}</a>
                </div>
                <div class="card-content">
                    <h3 class="card-title"><a href="${post.url}">${post.title}</a></h3>
                    <p class="card-summary"><a href="${post.url}">${post.paragraph}</a></p>
                </div>
                ${metaBlock}
            `;
            fragment.appendChild(card);
        });
        postsContainer.appendChild(fragment);
    };

    const updatePostsDisplay = () => {
        const postsToRender = currentFilteredPosts.slice(0, visiblePostCount);
        renderPosts(postsToRender);

        if (visiblePostCount >= currentFilteredPosts.length) {
            loadMoreBtn.style.display = "none";
        } else {
            loadMoreBtn.style.display = "block";
        }
    };

    const handleFilter = (filteredPosts) => {
        currentFilteredPosts = filteredPosts;
        visiblePostCount = POSTS_INITIAL_LOAD;
        updatePostsDisplay();
    };

    const applyFilters = () => {
        const category = document.querySelector(".category-list a.active-category")?.dataset.category || "all";
        const query = postFilterInput ? postFilterInput.value.trim().toLowerCase() : "";
        let filtered = allPosts;
        if (category.toLowerCase() !== "all") {
            filtered = filtered.filter((post) => post.category === category);
        }
        if (query) {
            filtered = window.GKApp.fuzzySearch(query, filtered);
        }
        handleFilter(filtered);
    };
  
    postsContainer.addEventListener('click', (event) => {
        const card = event.target.closest('.card');
        if (!card) return;

        const shareButton = event.target.closest('.share-button');
        if (shareButton) {
            event.preventDefault();
            const postIndex = parseInt(card.dataset.index, 10);
            const post = currentFilteredPosts[postIndex];

            if (post && navigator.share) {
                navigator.share({
                    title: post.title,
                    text: post.paragraph,
                    url: new URL(post.url, window.location.origin).href,
                }).catch((error) => console.log('Error sharing:', error));
            } else {
                alert('Share functionality is not supported by your browser.');
            }
        }
    });

    if (postFilterInput) {
        postFilterInput.addEventListener("input", applyFilters);
    }

    const generateCategories = () => {
        if (!categoryListContainer) return;

        const categoryCounts = allPosts.reduce((acc, post) => {
            if (post.category) {
                acc[post.category] = (acc[post.category] || 0) + 1;
            }
            return acc;
        }, {});

        const categoryDisplayNames = {
            'Conversion': 'Unit Conversion',
            'Vyakaran': 'Vyakaran'
        };

        let categoryHTML = `<li><a href="#" data-category="all" class="active-category">All Articles <span class="category-count">${allPosts.length}</span></a></li>`;

        Object.entries(categoryCounts).forEach(([category, count]) => {
            const displayName = categoryDisplayNames[category] || category;
            categoryHTML += `<li><a href="#" data-category="${category}">${displayName} <span class="category-count">${count}</span></a></li>`;
        });

        categoryListContainer.innerHTML = categoryHTML;

        const categoryLinks = categoryListContainer.querySelectorAll("a");
        categoryLinks.forEach((link) => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                categoryLinks.forEach((l) => l.classList.remove("active-category"));
                link.classList.add("active-category");
                applyFilters();
            });
        });
    };

    loadMoreBtn.addEventListener("click", () => {
        visiblePostCount += POSTS_PER_PAGE;
        updatePostsDisplay();
    });

    generateCategories();
    applyFilters();
});
