---
layout: default
title: GK Learn Study
description: Your one-stop destination for knowledge, tools, and tutorials
keywords: "latest GK, daily general knowledge, GK quizzes, learning articles, computer"
---

<main class="container">
        <div id="root">
            

  <style>
  
    .logo-container {
      border: 1px solid var(--card-border-color);
      border-radius: 16px;
      padding: 20px;
      display: flex;
      gap: 20px;

      
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      animation: fadeIn 1s ease-in-out;
    }
    .logo {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .text {
      flex: 2;
      display: flex;
      flex-direction: column;
      justify-content: center;
      animation: slideIn 1.2s ease-in-out;
    }
    .text h1 {text-align:left;
      font-size: 2rem;
     color: var(--accent-color);
      margin-bottom: 10px;
    }
   
    .text p {
      font-size: 1rem;
      color: var(--text-color-secondary);
      line-height: 1.6;
    }

    /* Mobile responsive */
    @media (max-width: 768px) {
      .logo-container {
        flex-direction: column;
       
      }
      .text h1 {
        font-size: 1.6rem;
      }
     
      .text p {
        font-size: 0.95rem;
      }
    }

    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.95); }
      to { opacity: 1; transform: scale(1); }
    }
    @keyframes slideIn {
      from { opacity: 0; transform: translateX(50px); }
      to { opacity: 1; transform: translateX(0); }
    }
  </style>


  <div class="logo-container">
    <!-- Left: Logo -->
    <div class="logo">
      <!-- Your SVG Logo -->
      <svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 300 300" role="img" aria-label="GK Learn Study logo">
        <title>GK Learn Study</title>
        <circle cx="150" cy="150" r="150" fill="white" />
        <defs>
          <clipPath id="circle-clip-main">
            <circle cx="150" cy="150" r="150" />
          </clipPath>
        </defs>
        <g clip-path="url(#circle-clip-main)">
          <path fill="#c0a4fb" fill-opacity="1">
            <animate attributeName="d" dur="8s" repeatCount="indefinite"
              values="M0 230 Q 75 210, 150 230 T 300 210 L 300 300 L 0 300 Z;
                      M0 240 Q 75 260, 150 240 T 300 250 L 300 300 L 0 300 Z;
                      M0 230 Q 75 210, 150 230 T 300 210 L 300 300 L 0 300 Z" />
          </path>
          <path fill="#641ef9" fill-opacity="0.7">
            <animate attributeName="d" dur="7s" repeatCount="indefinite"
              values="M0 220 Q 75 245, 150 220 T 300 235 L 300 300 L 0 300 Z;
                      M0 250 Q 75 220, 150 250 T 300 220 L 300 300 L 0 300 Z;
                      M0 220 Q 75 245, 150 220 T 300 235 L 300 300 L 0 300 Z" />
          </path>
        </g>
        <text x="50%" y="35%" font-size="90" font-weight="700" fill="#e53935" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" style="transform-origin:150px 90px;" opacity="0">
          GK
          <animate attributeName="opacity" from="0" to="1" begin="0.35s" dur="1.2s" fill="freeze" />
          <animateTransform attributeName="transform" type="rotate" from="-15 150 90" to="0 150 90" begin="0.35s" dur="1.2s" fill="freeze" additive="sum" />
          <animateTransform attributeName="transform" type="scale" from="0.55 0.55" to="1 1" begin="0.35s" dur="1.2s" fill="freeze" additive="sum" />
        </text>
        <text x="50%" y="65%" font-size="38" fill="#6a1b9a" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" style="transform-origin:150px 195px;" opacity="0">
          Learn Study
          <animate attributeName="opacity" from="0" to="1" begin="0.8s" dur="1.2s" fill="freeze" />
          <animateTransform attributeName="transform" type="scale" from="0.75 0.75" to="1 1" begin="0.8s" dur="1.2s" fill="freeze" />
        </text>
        <circle cx="150" cy="150" r="145" fill="none" stroke="#f0e6ff" stroke-width="4" opacity="0.6"/>
      </svg>
    </div>

    <!-- Right: Text -->
    <div class="text">
      <h1>Welcome to GK Learn Study</h1>
      <p>
        Your daily source for insightful articles, handy tools, and general knowledge.<br>
        Dive in and explore a world of learning, made simple and accessible for everyone.
      </p>
    </div>
  </div>



         
                <div class="categories-section sidebar-widget">
                  <style>
  .h2-icons {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 1.6rem;
    font-weight: 600;
  }
  .h2-icons svg {
    width: 24px;
    height: 24px;
  }

  /* Arrow animation */
  .arrow-anim {
    animation: moveArrow 1.2s infinite ease-in-out;
  }
  @keyframes moveArrow {
    0%,100% { transform: translateX(0); }
    50%     { transform: translateX(6px); }
  }

  /* Box color cycle */
  @keyframes colorCycle {
    0%   { fill: #4285F4; }  /* Blue */
    25%  { fill: #EA4335; }  /* Red */
    50%  { fill: #FBBC05; }  /* Yellow */
    75%  { fill: #34A853; }  /* Green */
    100% { fill: #4285F4; }
  }
  .box1 { animation: colorCycle 4s infinite; }
  .box2 { animation: colorCycle 4s infinite 1s; }
  .box3 { animation: colorCycle 4s infinite 2s; }
  .box4 { animation: colorCycle 4s infinite 3s; }

  /* Categories text animation */
  @keyframes textColorCycle {
    0%   { color: #4285F4; }
    25%  { color: #EA4335; }
    50%  { color: #FBBC05; }
    75%  { color: #34A853; }
    100% { color: #4285F4; }
  }
  .animated-text {
    animation: textColorCycle 4s infinite linear;
  }
</style>

<h2 class="h2-icons">
  <!-- Animated 4 boxes -->
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <rect class="box1" x="2"  y="2"  width="8" height="8" rx="1.5"/>
    <rect class="box2" x="14" y="2"  width="8" height="8" rx="1.5"/>
    <rect class="box3" x="2"  y="14" width="8" height="8" rx="1.5"/>
    <rect class="box4" x="14" y="14" width="8" height="8" rx="1.5"/>
  </svg>

  <!-- Animated text -->
  <span class="animated-text">Categories</span>

  <!-- Animated arrow -->
  <svg class="arrow-anim" viewBox="0 0 24 24" stroke="#641ef9" fill="none"
       stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"
       xmlns="http://www.w3.org/2000/svg">
    <path d="M3 12h14"/>
    <path d="M14 6l6 6-6 6"/>
  </svg>
</h2>

                    <ul class="category-list">
                        <!-- Categories will be dynamically injected here -->
                    </ul>
                </div>

                <div class="post-filter-container">
                    <input type="text" id="post-filter-input" placeholder="Filter articles by title, content, or author..." aria-label="Filter articles" />
                </div>

                <main id="post-grid" class="post-grid">
                

                </main>

                <div id="load-more-container">
                    <button id="load-more-btn">Load More</button>
                </div>
            </div>
        </div>
    </main>
